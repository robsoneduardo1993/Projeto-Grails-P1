package empodera

import grails.testing.services.ServiceUnitTest
import spock.lang.Specification

class UsuarioServiceSpec extends Specification implements ServiceUnitTest<UsuarioService>{

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
