package empodera

import grails.testing.gorm.DomainUnitTest
import spock.lang.Specification

class UsuarioSpec extends Specification implements DomainUnitTest<Usuario>
 {

    def setup() {
        new Usuario(nome:"Robson", email:"gmail", time:"Barcelona",posicao: "zagueiro", idade: 25)
    }

    def cleanup() {
    }

    void "test something"() {
        given:
        setupData()

        expect:
        Usuario.count() == 1
    }
}
