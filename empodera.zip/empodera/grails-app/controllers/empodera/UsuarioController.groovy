package empodera

class UsuarioController {

    static scaffold = Usuario
}
