package empodera

import grails.gorm.transactions.Transactional

@Transactional
class UsuarioService {

    def serviceMethod() {

    }
}
