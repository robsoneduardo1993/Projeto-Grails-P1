package empodera

class Usuario {
    //atributos
    String nome;
    String email;
    String time;
    String posicao;
    int idade;

    //restriçoes das variaveis
    static constraints = {
        nome nullable:false, blank:false, maxSize:128, unique:false
        email nullable:false, blank:false, maxSize:128, unique:true
        time nullable:false, blank:false, maxSize:128, unique:false
        posicao nullable:false, blank:false, maxSize:128, unique:false
        idade nullable:false, blank:false,min: 12, max:99, unique:false
    }
// mapeamento das variaveis com as colunas do banco de dados
    static mapping = {
        table "usuario"
        nome column: "nome"
        email column: "email"
        time column: "ttime"
        posicao column: "posicao"
        idade column:"idade"
    }
}
